<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <script src="https://kit.fontawesome.com/ae58c7a07e.js" crossorigin="anonymous"></script>
    <title>Neteisingai</title>
    </head>
<body>
    <section>
    <h1>Neteisingai...</h1>
    <p class="emoji"><i class="fas fa-frown-open"></i></p>
    <div class="start">
        <a href="/php/tomas_projektas/second/index.php"><i class="fas fa-arrow-left"></i> Bandyti dar kartą</a>
            </div>
            <p>P.S.:Pavadinimai rašomi iš didžiosios raidės. <i class="far fa-smile-wink"></i>       
    <p id="start"></p>
</section>
<footer><?php echo '&copy;'.date('Y');?></footer>
</body>
</html>