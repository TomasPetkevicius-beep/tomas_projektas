$(document).ready(function() {
    $(`#cf`).click(function() {
      $(`#cf1`).toggle();
    });
  });

  $(document).ready(function() {
    $(`#kz`).click(function() {
      $(`#inst`).toggle();
    });
  });