<?php
require __DIR__.'/app/src/app.php';
include_once 'header1.php';
?>


    <section>
        <img src="img/titul.jpg" alt="Grandinele_picture">

    <p style="font-family: 'Merriweather', serif;">Įdomus, interaktyvus žaidimas tau, tavo šeimai ir draugams!</p
    >
    <br>
    <div class="start">
<a href="first/index.php"><i class="fas fa-space-shuttle"></i>PRADĖTI</i></a>
    </div>
    </section>
    <script src="script.js"></script>
    <script src="jquery-3.5.1.min.js"></script>
    <script src="script1.js"></script>
    <?php include("../tomas_projektas/app/views/footer.php");?> 
</body>
</html>